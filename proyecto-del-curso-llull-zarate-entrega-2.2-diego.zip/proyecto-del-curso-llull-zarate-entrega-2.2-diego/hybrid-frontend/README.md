Funciona para el ios simulator 
backend()
rails db:migrate
rails db:seed
rails server -b 0.0.0.0 -p 3001

hybrid-frontend()
npm start
ios simulator
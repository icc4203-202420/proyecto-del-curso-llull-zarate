require "test_helper"

class ReviewCounterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

class ReviewCounter < ApplicationRecord
end

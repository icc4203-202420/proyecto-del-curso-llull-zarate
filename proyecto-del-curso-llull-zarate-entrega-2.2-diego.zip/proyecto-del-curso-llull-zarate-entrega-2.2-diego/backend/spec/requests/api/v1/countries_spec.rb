require 'rails_helper'

RSpec.describe "API::V1::Countries", type: :request do
  describe "GET /index" do
    pending "add some examples (or delete) #{__FILE__}"
  end
end

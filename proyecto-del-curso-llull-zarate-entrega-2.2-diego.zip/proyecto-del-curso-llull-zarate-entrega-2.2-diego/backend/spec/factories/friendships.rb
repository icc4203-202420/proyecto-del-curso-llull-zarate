FactoryBot.define do
  factory :friendship do
    user { nil }
    friend { nil }
  end
end

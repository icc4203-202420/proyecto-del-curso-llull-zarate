FactoryBot.define do
  factory :event do
    name { "MyString" }
    description { "MyText" }
    date { "2024-08-09 09:44:49" }
    bar { nil }
  end
end

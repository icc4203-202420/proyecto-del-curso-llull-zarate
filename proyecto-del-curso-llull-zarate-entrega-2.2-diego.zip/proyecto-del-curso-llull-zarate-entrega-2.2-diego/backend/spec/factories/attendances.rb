FactoryBot.define do
  factory :attendance do
    user { nil }
    event { nil }
  end
end

FactoryBot.define do
  factory :event_picture do
    event { nil }
    user { nil }
    description { "MyText" }
  end
end

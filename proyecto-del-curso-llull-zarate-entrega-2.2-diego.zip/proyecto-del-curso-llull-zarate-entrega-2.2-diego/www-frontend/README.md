# Aplicación de Frontend (React + Vite)

## Descripción

Esta aplicación de frontend se encuentra implementada con React utilizando Vite como andamiaje para despliegue en desarrollo y para empaquetamiento de producción.

Incluye lo más básico y elemental y será completada en las entregas sucesivas de proyecto.

## Ejecución

Para ejecutar esta aplicación en modo de desarrollo, el comando básico es:

```sh
yarn dev
```

Es posible detener la aplicación con Ctrl+C.